package com.example.kanban;

public @interface Entity {
}
